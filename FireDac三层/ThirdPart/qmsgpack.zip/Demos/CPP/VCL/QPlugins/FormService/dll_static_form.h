//---------------------------------------------------------------------------

#ifndef dll_static_formH
#define dll_static_formH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "qplugins.hpp"
#include <Vcl.AppEvnts.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm,public IQNotify
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Label2;
	TMemo *Memo1;
private:	// User declarations
    void __stdcall Notify(const unsigned AId, Qplugins_params::_di_IQParams AParams, bool &AFireNext);
public:		// User declarations
	__fastcall TForm2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
