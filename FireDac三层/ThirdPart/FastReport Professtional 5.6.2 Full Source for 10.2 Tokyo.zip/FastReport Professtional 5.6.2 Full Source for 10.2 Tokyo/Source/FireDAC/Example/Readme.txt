FastReport 4 AddOn Example

This example uses FireDAC sample MS Access database.
Sample database should be located in \Users\Public\Documents\RAD Studio\12.0\Samples\data\dbdemos.mdb.
You can change this path in TFDConnection component editors.