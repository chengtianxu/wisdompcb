﻿// CodeGear C++Builder
// Copyright (c) 1995, 2017 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_idialogsrtti.pas' rev: 32.00 (Windows)

#ifndef Fs_idialogsrttiHPP
#define Fs_idialogsrttiHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <fs_iinterpreter.hpp>
#include <fs_iclassesrtti.hpp>
#include <System.UITypes.hpp>
#include <Vcl.Dialogs.hpp>
#include <System.Types.hpp>
#include <Vcl.Controls.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fs_idialogsrtti
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TfsDialogsRTTI;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TfsDialogsRTTI : public System::Classes::TComponent
{
	typedef System::Classes::TComponent inherited;
	
public:
	/* TComponent.Create */ inline __fastcall virtual TfsDialogsRTTI(System::Classes::TComponent* AOwner) : System::Classes::TComponent(AOwner) { }
	/* TComponent.Destroy */ inline __fastcall virtual ~TfsDialogsRTTI(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Fs_idialogsrtti */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FS_IDIALOGSRTTI)
using namespace Fs_idialogsrtti;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fs_idialogsrttiHPP
