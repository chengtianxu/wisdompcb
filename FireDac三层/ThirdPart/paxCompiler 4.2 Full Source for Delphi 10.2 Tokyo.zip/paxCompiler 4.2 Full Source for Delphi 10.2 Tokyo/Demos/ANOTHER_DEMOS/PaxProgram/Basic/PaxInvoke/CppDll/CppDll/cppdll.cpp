#include "cppdll.h"

//prevent function name from being mangled
extern "C" 

int __fastcall cube(int num) 
{
	return num * num * num;
}

double __fastcall arr(double a[], int i, int j, float f) 
{
	return a[0] + a[1] + i + j + f;
}

char __fastcall ret_char(char * s)
{
	return s[0];
}

MyPoint __fastcall ret_struct(int x, int y, int z)
{
	MyPoint p;
	p.x = x;
	p.y = y;
	p.z = z;
	return p;
}

MyPoint2 __fastcall ret_struct2(int x, int y)
{
	MyPoint2 p;
	p.x = x;
	p.y = y;
	return p;
}

MyPoint __fastcall pass_struct(const MyPoint & q)
{
	MyPoint p;
	p.x = q.x;
	p.y = q.y;
	p.z = q.z;
	return p;
}

MyPoint __fastcall pass_struct_byval(MyPoint q)
{
	MyPoint p;
	p.x = q.x;
	p.y = q.y;
	p.z = q.z;
	return p;
}

double __fastcall dcube(double num) 
{
	return num * num * num;
}

float __fastcall fcube(float num) 
{
	return num * num * num;
}


