/*
	this header is not required for this dll
	to compile; but is required for the app
	that will use this dll
*/

#ifndef CPPDLL_H
#define CPPDLL_H

struct MyPoint
{
	int x;
	int y;
	int z;
};

struct MyPoint2
{
	int x;
	int y;
};

extern "C" 
int __fastcall cube(int num);
double __fastcall arr(double a[], int i, int j, float f);
char __fastcall ret_char(char * s);
MyPoint __fastcall ret_struct(int x, int y, int z);
MyPoint2 __fastcall ret_struct2(int x, int y);
MyPoint __fastcall pass_struct(const MyPoint & q);
MyPoint __fastcall pass_struct_byval(MyPoint q);
double __fastcall dcube(double num); 
float __fastcall fcube(float num); 

#endif //CPPDLL_H