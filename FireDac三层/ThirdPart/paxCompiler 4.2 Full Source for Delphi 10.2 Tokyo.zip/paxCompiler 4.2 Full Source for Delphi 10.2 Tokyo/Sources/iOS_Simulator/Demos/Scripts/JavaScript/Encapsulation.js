// encapsulation

function MyClass()
{
    this.m_data = 5;
    this.m_text = "Hello World";
    this.SetData = SetData;
    this.SetText = SetText;
    this.ShowData = DisplayData;
    this.ShowText = DisplayText;

    function DisplayData()
    {
        print( this.m_data );
    }

    function DisplayText()
    {
        print( this.m_text );
        return;
    }

    function SetData( myVal )
    {
        this.m_data = myVal;
    }

    function SetText( myText )
    {
        this.m_text = myText;
    }
}

var myClassObj1 = new MyClass();
var myClassObj2 = new MyClass();
myClassObj1.SetData( 10 );
myClassObj1.SetText( "Obj1:  Hello World" );
myClassObj2.SetData( 20 );
myClassObj2.SetText( "Obj2:  Hello World" );
myClassObj1.ShowData();    // displays: 10
myClassObj1.ShowText();    // displays: "Obj1:  Hello World"
myClassObj2.ShowData();    // displays: 20
myClassObj2.ShowText();    // displays: "Obj2:  Hello World"