using Classes;
x = new TStringList();
x.Add("abc");
var i;
with (x)
{
  i = Add("http://www.paxcompiler.com");
}
print(i);






