function sayHello2(name) {
    var text = 'Hello ' + name; // Local variable
    var sayAlert = function() { alert(text); };
    return sayAlert;
}
say2 = sayHello2('Bob');
say2(); // alerts "Hello Bob"