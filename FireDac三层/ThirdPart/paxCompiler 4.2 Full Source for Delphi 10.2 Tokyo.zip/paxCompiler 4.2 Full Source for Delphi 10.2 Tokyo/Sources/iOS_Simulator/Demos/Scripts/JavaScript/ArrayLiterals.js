a = [10, 20, ];
for (i in a)
  print(a[i]);