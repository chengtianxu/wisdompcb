var x = new String;
for (i=0; i <100000; i++)
with (x)
{
  y = anchor("http://www.paxcompiler.com");
}
println(y);



 



