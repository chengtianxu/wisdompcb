function f(g, x)
{
  return g(x);
}

function p(x)
{
  return x + x;
}

print(f(p, 5));


