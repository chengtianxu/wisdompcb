function foo(x) {
  var tmp = 3;
  this.bar = bar;
  function bar(y) {
    print(x + y + (++tmp));
  }
  bar(10);
}
foo(2);
