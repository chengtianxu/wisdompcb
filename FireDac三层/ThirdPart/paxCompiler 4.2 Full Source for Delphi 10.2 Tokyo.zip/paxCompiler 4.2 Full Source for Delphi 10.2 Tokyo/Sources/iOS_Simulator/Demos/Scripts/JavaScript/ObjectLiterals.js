x = {'abc': 100, 'pqr': 200};
for (var i in x)
  print(x[i]);