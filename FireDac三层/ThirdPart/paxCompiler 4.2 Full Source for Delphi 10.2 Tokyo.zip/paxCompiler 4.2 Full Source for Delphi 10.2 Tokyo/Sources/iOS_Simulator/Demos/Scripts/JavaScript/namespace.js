var yourNamespace = {

    foo: function()
    {
      print 1;
    },

    bar: function()
    {
      print 2;
    }
};

yourNamespace.foo();