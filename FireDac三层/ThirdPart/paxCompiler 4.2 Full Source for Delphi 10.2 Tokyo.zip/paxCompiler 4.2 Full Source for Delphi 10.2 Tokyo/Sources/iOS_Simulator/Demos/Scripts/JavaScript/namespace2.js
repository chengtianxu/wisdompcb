var ns = new function() {

    var a = 5;

    var internalFunction = function() {
      print 1;
    };

    this.publicFunction = function() {
      print 2;
    };
};

ns.publicFunction();