paxCompiler sources
------------------------------------------------------------------------------
Version: 4.2
Status: Registered.
Build: 14 October, 2014.
Copyright (c) 2006-2014 Alexander Baranovsky
Author: Alexander Baranovsky
Web site: www.paxcompiler.com

Xilinx Tokyio mod: 7 August 2017


